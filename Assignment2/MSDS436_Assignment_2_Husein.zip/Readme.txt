#***********************************************
MSDS 436 Assignment 2
By – Husein Adenwala
Date - 2/06/2022
#***********************************************/

## Assignment description.

Use Postman to create a collection of 4 APIs that load dataset onto S3 
Upload dataset from S3 into Elasticsearch and run 4  queries
$ Cypher queries in Neo4j to provide insight intot panama dataset 


## files and Scripts: contains the following Folder

aws_restapi.py python script uses flask to create Rest API for S3
MSDS_436_Assignment2.postman_collection.json has the colletion of 4 postman API's 
process_brfss_data.py python script for uplading S3 data to Elastisearch.
Elasticsearch_queries.txt shows the collesiton of 4 elasticsearch queries
Console - Kibana.html show the Elastic search queries as done in Kibana 
Cypher_queries.txt has the 4 cypher queres done in Neog4j for the panama dataset 



